# WordPress MySQL database migration
#
# Generated: Saturday 2. May 2015 04:36 UTC
# Hostname: localhost
# Database: `samanthanissen_db`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-04-17 02:08:50', '2015-04-17 02:08:50', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_duplicator_packages`
#

DROP TABLE IF EXISTS `wp_duplicator_packages`;


#
# Table structure of table `wp_duplicator_packages`
#

CREATE TABLE `wp_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_duplicator_packages`
#
INSERT INTO `wp_duplicator_packages` ( `id`, `name`, `hash`, `status`, `created`, `owner`, `package`) VALUES
(1, 'samanthanissenportfolio', '5534969b2c8978515150420060307', 100, '2015-04-20 06:04:18', 'snissen', 'O:11:"DUP_Package":16:{s:2:"ID";i:1;s:4:"Name";s:23:"samanthanissenportfolio";s:4:"Hash";s:29:"5534969b2c8978515150420060307";s:8:"NameHash";s:53:"samanthanissenportfolio_5534969b2c8978515150420060307";s:7:"Version";s:6:"0.5.16";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:58:"/Applications/MAMP/htdocs/samantha-nissen/wp-snapshots/tmp";s:8:"StoreURL";s:51:"http://localhost:8888/samantha-nissen/wp-snapshots/";s:8:"ScanFile";s:63:"samanthanissenportfolio_5534969b2c8978515150420060307_scan.json";s:7:"Runtime";s:10:"31.65 sec.";s:7:"ExeSize";s:8:"316.96KB";s:7:"ZipSize";s:7:"36.24MB";s:7:"Archive";O:11:"DUP_Archive":17:{s:10:"FilterDirs";s:0:"";s:10:"FilterExts";s:0:"";s:8:"FilterOn";i:0;s:4:"File";s:65:"samanthanissenportfolio_5534969b2c8978515150420060307_archive.zip";s:6:"Format";s:3:"ZIP";s:7:"PackDir";s:41:"/Applications/MAMP/htdocs/samantha-nissen";s:4:"Size";i:38002354;s:12:"WarnFileSize";a:0:{}s:12:"WarnFileName";a:0:{}s:4:"Dirs";a:0:{}s:5:"Files";a:0:{}s:5:"Links";a:0:{}s:8:"OmitDirs";a:0:{}s:9:"OmitFiles";a:0:{}s:10:"\0*\0Package";r:1;s:28:"\0DUP_Archive\0filterDirsArray";a:0:{}s:28:"\0DUP_Archive\0filterExtsArray";a:0:{}}s:9:"Installer";O:13:"DUP_Installer":11:{s:4:"File";s:67:"samanthanissenportfolio_5534969b2c8978515150420060307_installer.php";s:4:"Size";i:324568;s:10:"OptsDBHost";s:9:"localhost";s:10:"OptsDBName";s:17:"snissen_portfolio";s:10:"OptsDBUser";s:12:"snissen_main";s:12:"OptsSSLAdmin";i:0;s:12:"OptsSSLLogin";i:0;s:11:"OptsCacheWP";i:0;s:13:"OptsCachePath";i:0;s:10:"OptsURLNew";s:26:"http://samanthanissen.com/";s:10:"\0*\0Package";r:1;}s:8:"Database";O:12:"DUP_Database":11:{s:4:"Type";s:5:"MySQL";s:4:"Size";i:402949;s:4:"File";s:66:"samanthanissenportfolio_5534969b2c8978515150420060307_database.sql";s:4:"Path";N;s:12:"FilterTables";s:0:"";s:8:"FilterOn";i:0;s:4:"Name";N;s:10:"\0*\0Package";r:1;s:25:"\0DUP_Database\0dbStorePath";s:125:"/Applications/MAMP/htdocs/samantha-nissen/wp-snapshots/tmp/samanthanissenportfolio_5534969b2c8978515150420060307_database.sql";s:23:"\0DUP_Database\0EOFMarker";s:0:"";s:26:"\0DUP_Database\0networkFlush";b:0;}}') ;

#
# End of data contents of table `wp_duplicator_packages`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://samanthanissen.com', 'yes'),
(2, 'home', 'http://samanthanissen.com', 'yes'),
(3, 'blogname', 'Samantha Nissen', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'samanthaknissen@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'portfolio', 'yes'),
(42, 'stylesheet', 'portfolio', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '30133', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '19', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '30133', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:5:{i:1430551980;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1430575742;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1430589532;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1430602187;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(102, 'auth_key', 'V=T.C6[-~Cdb{it6%QpCxq1_c Z]X`H 5-~FfO~jixETg>nt5d73?x{[9BT@f`4=', 'yes'),
(103, 'auth_salt', '?7F#H$*+unqm=81,9]g,bmY*Pns0!j]$k^?EUx(A&*P8QvF{8 Afps^hy?XCg_jN', 'yes'),
(104, 'logged_in_key', 'C/]<dmuZ`YCgutEc6;5MXLZD|R#Lpl3F0C>&[a}Rw&fxoi+$P<5qWdJObgl]/TJR', 'yes'),
(105, 'logged_in_salt', '.P,/VI-s%r19Ys~5Il_&E4+s~R|4-.pBVOgH]o^zeAdUp%r`7O4kjftXWb=d6%83', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(109, 'nonce_key', ']{tiicD@)Ce@Ic NlCKzR`?Hq1dR`x5R#[ROX^I9C[s$]=1VTOYI=^H6PPb5gCw-', 'yes'),
(110, 'nonce_salt', '&J.B[_yy0cV|DXY8DhZ~|q>G@A+PEf]p|as< I-@YE[}n-7ry^wF6,mn$34XpkjQ', 'yes'),
(114, 'can_compress_scripts', '1', 'yes'),
(152, 'recently_activated', 'a:3:{s:33:"wordpress-move/wordpress-move.php";i:1429512327;s:34:"wp-clone-by-wp-academy/wpclone.php";i:1429510623;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:1429509780;}', 'yes'),
(155, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1429380394;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(156, 'current_theme', 'portfolio', 'yes'),
(157, 'theme_mods_portfolio', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}}', 'yes'),
(158, 'theme_switched', '', 'yes'),
(167, 'acf_version', '4.4.1', 'yes'),
(172, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(182, 'ai1wm_secret_key', 'LXp3spJSi1iv', 'yes'),
(183, 'ai1wm_messages', 'a:1:{s:17:"SiteURLDepricated";b:0;}', 'yes'),
(208, 'duplicator_settings', 'a:10:{s:7:"version";s:6:"0.5.16";s:18:"uninstall_settings";b:1;s:15:"uninstall_files";b:1;s:16:"uninstall_tables";b:1;s:13:"package_debug";b:0;s:17:"package_mysqldump";b:0;s:22:"package_mysqldump_path";s:0:"";s:24:"package_phpdump_qrylimit";s:3:"100";s:17:"package_zip_flush";b:0;s:20:"storage_htaccess_off";b:0;}', 'yes'),
(209, 'duplicator_version_plugin', '0.5.16', 'yes'),
(210, 'duplicator_ui_view_state', 'a:3:{s:14:"dup-wpnotice01";b:1;s:24:"dup-pack-installer-panel";s:1:"1";s:22:"dup-pack-archive-panel";s:1:"1";}', 'yes'),
(211, 'duplicator_package_active', 'O:11:"DUP_Package":16:{s:2:"ID";N;s:4:"Name";s:23:"samanthanissenportfolio";s:4:"Hash";s:29:"5534969b2c8978515150420060307";s:8:"NameHash";s:53:"samanthanissenportfolio_5534969b2c8978515150420060307";s:7:"Version";s:6:"0.5.16";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:58:"/Applications/MAMP/htdocs/samantha-nissen/wp-snapshots/tmp";s:8:"StoreURL";s:51:"http://localhost:8888/samantha-nissen/wp-snapshots/";s:8:"ScanFile";s:63:"samanthanissenportfolio_5534969b2c8978515150420060307_scan.json";s:7:"Runtime";N;s:7:"ExeSize";N;s:7:"ZipSize";N;s:7:"Archive";O:11:"DUP_Archive":17:{s:10:"FilterDirs";s:0:"";s:10:"FilterExts";s:0:"";s:8:"FilterOn";i:0;s:4:"File";N;s:6:"Format";s:3:"ZIP";s:7:"PackDir";s:41:"/Applications/MAMP/htdocs/samantha-nissen";s:4:"Size";i:0;s:12:"WarnFileSize";a:0:{}s:12:"WarnFileName";a:0:{}s:4:"Dirs";a:0:{}s:5:"Files";a:0:{}s:5:"Links";a:0:{}s:8:"OmitDirs";a:0:{}s:9:"OmitFiles";a:0:{}s:10:"\0*\0Package";O:11:"DUP_Package":16:{s:2:"ID";N;s:4:"Name";s:23:"samanthanissenportfolio";s:4:"Hash";s:29:"5534969b2c8978515150420060307";s:8:"NameHash";s:53:"samanthanissenportfolio_5534969b2c8978515150420060307";s:7:"Version";s:6:"0.5.16";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:58:"/Applications/MAMP/htdocs/samantha-nissen/wp-snapshots/tmp";s:8:"StoreURL";s:51:"http://localhost:8888/samantha-nissen/wp-snapshots/";s:8:"ScanFile";N;s:7:"Runtime";N;s:7:"ExeSize";N;s:7:"ZipSize";N;s:7:"Archive";r:15;s:9:"Installer";O:13:"DUP_Installer":11:{s:4:"File";N;s:4:"Size";i:0;s:10:"OptsDBHost";s:9:"localhost";s:10:"OptsDBName";s:17:"snissen_portfolio";s:10:"OptsDBUser";s:12:"snissen_main";s:12:"OptsSSLAdmin";i:0;s:12:"OptsSSLLogin";i:0;s:11:"OptsCacheWP";i:0;s:13:"OptsCachePath";i:0;s:10:"OptsURLNew";s:26:"http://samanthanissen.com/";s:10:"\0*\0Package";r:30;}s:8:"Database";O:12:"DUP_Database":11:{s:4:"Type";s:5:"MySQL";s:4:"Size";N;s:4:"File";N;s:4:"Path";N;s:12:"FilterTables";s:0:"";s:8:"FilterOn";i:0;s:4:"Name";N;s:10:"\0*\0Package";r:30;s:25:"\0DUP_Database\0dbStorePath";N;s:23:"\0DUP_Database\0EOFMarker";s:0:"";s:26:"\0DUP_Database\0networkFlush";b:0;}}s:28:"\0DUP_Archive\0filterDirsArray";a:0:{}s:28:"\0DUP_Archive\0filterExtsArray";a:0:{}}s:9:"Installer";r:45;s:8:"Database";r:57;}', 'yes'),
(216, 'wpmove_options', 'a:7:{s:13:"db_chunk_size";i:0;s:13:"fs_chunk_size";i:10;s:12:"ftp_hostname";s:9:"localhost";s:8:"ftp_port";i:21;s:12:"ftp_username";s:12:"snissen_main";s:16:"ftp_passive_mode";i:1;s:15:"ftp_remote_path";s:0:"";}', 'yes'),
(243, 'cptui_post_types', 'a:1:{s:4:"work";a:22:{s:4:"name";s:4:"work";s:5:"label";s:5:"works";s:14:"singular_label";s:4:"work";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:7:"show_ui";s:4:"true";s:11:"has_archive";s:4:"true";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";N;s:8:"supports";a:0:{}s:10:"taxonomies";a:0:{}s:6:"labels";a:13:{s:9:"menu_name";s:0:"";s:9:"all_items";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}}', 'yes'),
(259, 'rewrite_rules', 'a:88:{s:7:"work/?$";s:24:"index.php?post_type=work";s:37:"work/feed/(feed|rdf|rss|rss2|atom)/?$";s:41:"index.php?post_type=work&feed=$matches[1]";s:32:"work/(feed|rdf|rss|rss2|atom)/?$";s:41:"index.php?post_type=work&feed=$matches[1]";s:24:"work/page/([0-9]{1,})/?$";s:42:"index.php?post_type=work&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:32:"work/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"work/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"work/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:25:"work/([^/]+)/trackback/?$";s:31:"index.php?work=$matches[1]&tb=1";s:45:"work/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?work=$matches[1]&feed=$matches[2]";s:40:"work/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?work=$matches[1]&feed=$matches[2]";s:33:"work/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&paged=$matches[2]";s:40:"work/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&cpage=$matches[2]";s:25:"work/([^/]+)(/[0-9]+)?/?$";s:43:"index.php?work=$matches[1]&page=$matches[2]";s:21:"work/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"work/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"work/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=19&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'work.php'),
(2, 2, '_edit_lock', '1429504610:1'),
(3, 4, '_edit_last', '1'),
(4, 4, 'field_55341f0e12d23', 'a:11:{s:3:"key";s:19:"field_55341f0e12d23";s:5:"label";s:4:"Role";s:4:"name";s:4:"role";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(5, 4, 'field_55341f3112d24', 'a:11:{s:3:"key";s:19:"field_55341f3112d24";s:5:"label";s:6:"Skills";s:4:"name";s:6:"skills";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(6, 4, 'field_55341f4b12d25', 'a:11:{s:3:"key";s:19:"field_55341f4b12d25";s:5:"label";s:6:"Client";s:4:"name";s:6:"client";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(7, 4, 'field_55341f9312d26', 'a:11:{s:3:"key";s:19:"field_55341f9312d26";s:5:"label";s:10:"Work Image";s:4:"name";s:10:"work-image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:2:"id";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(9, 4, 'position', 'normal'),
(10, 4, 'layout', 'no_box'),
(11, 4, 'hide_on_screen', ''),
(12, 4, '_edit_lock', '1430073696:1'),
(13, 5, '_wp_attached_file', '2015/04/noel-nissen.jpg'),
(14, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3264;s:6:"height";i:2448;s:4:"file";s:23:"2015/04/noel-nissen.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"noel-nissen-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"noel-nissen-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"noel-nissen-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:2.399999999999999911182158029987476766109466552734375;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 5c";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1418722994;s:9:"copyright";s:36:"Copyright 2014. All rights reserved.";s:12:"focal_length";s:4:"4.12";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:16:"0.00833333333333";s:5:"title";s:37:"Processed with VSCOcam with c1 preset";s:11:"orientation";i:1;}}'),
(15, 5, '_wp_attachment_image_alt', 'Noel Nissen'),
(16, 2, '_edit_last', '1'),
(17, 7, 'role', 'Logo design, web design and development'),
(18, 7, '_role', 'field_55341f0e12d23'),
(19, 7, 'skills', 'HTML5, CSS, Wordpress, Responsive'),
(20, 7, '_skills', 'field_55341f3112d24'),
(21, 7, 'client', 'Noel Nissen'),
(22, 7, '_client', 'field_55341f4b12d25'),
(23, 7, 'work_image', '5'),
(24, 7, '_work_image', 'field_55341f9312d26'),
(25, 2, 'role', 'Logo design, web design and development'),
(26, 2, '_role', 'field_55341f0e12d23'),
(27, 2, 'skills', 'HTML5, CSS, Wordpress, Responsive'),
(28, 2, '_skills', 'field_55341f3112d24'),
(29, 2, 'client', 'Noel Nissen'),
(30, 2, '_client', 'field_55341f4b12d25'),
(31, 2, 'work_image', '5'),
(32, 2, '_work_image', 'field_55341f9312d26'),
(33, 4, 'field_553424fb5c261', 'a:11:{s:3:"key";s:19:"field_553424fb5c261";s:5:"label";s:5:"About";s:4:"name";s:5:"about";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(37, 8, 'about', 'Noel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region.'),
(38, 8, '_about', 'field_553424fb5c261'),
(39, 8, 'role', 'Logo design, web design and development'),
(40, 8, '_role', 'field_55341f0e12d23'),
(41, 8, 'skills', 'HTML5, CSS, Wordpress, Responsive'),
(42, 8, '_skills', 'field_55341f3112d24'),
(43, 8, 'client', 'Noel Nissen'),
(44, 8, '_client', 'field_55341f4b12d25'),
(45, 8, 'work_image', '5'),
(46, 8, '_work_image', 'field_55341f9312d26'),
(47, 2, 'about', 'Noel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region.'),
(48, 2, '_about', 'field_553424fb5c261'),
(49, 9, '_menu_item_type', 'custom'),
(50, 9, '_menu_item_menu_item_parent', '0'),
(51, 9, '_menu_item_object_id', '9'),
(52, 9, '_menu_item_object', 'custom'),
(53, 9, '_menu_item_target', ''),
(54, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(55, 9, '_menu_item_xfn', ''),
(56, 9, '_menu_item_url', 'http://samanthanissen.com/'),
(76, 12, '_menu_item_type', 'custom'),
(77, 12, '_menu_item_menu_item_parent', '0'),
(78, 12, '_menu_item_object_id', '12'),
(79, 12, '_menu_item_object', 'custom'),
(80, 12, '_menu_item_target', ''),
(81, 12, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 12, '_menu_item_xfn', ''),
(83, 12, '_menu_item_url', 'http://samanthanissen.com/'),
(89, 13, 'about', 'Noel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region.'),
(90, 13, '_about', 'field_553424fb5c261'),
(91, 13, 'role', 'Logo design, web design and development'),
(92, 13, '_role', 'field_55341f0e12d23'),
(93, 13, 'skills', 'HTML5, CSS, Wordpress, Responsive'),
(94, 13, '_skills', 'field_55341f3112d24'),
(95, 13, 'client', 'Noel Nissen'),
(96, 13, '_client', 'field_55341f4b12d25'),
(97, 13, 'work-image', '5'),
(98, 13, '_work-image', 'field_55341f9312d26'),
(99, 2, 'work-image', '5'),
(100, 2, '_work-image', 'field_55341f9312d26'),
(102, 1, '_edit_lock', '1429482505:1'),
(103, 4, 'field_55347ffee055b', 'a:11:{s:3:"key";s:19:"field_55347ffee055b";s:5:"label";s:5:"Title";s:4:"name";s:5:"title";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(105, 14, 'about', 'Noel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region.'),
(106, 14, '_about', 'field_553424fb5c261'),
(107, 14, 'role', 'Logo design, web design and development'),
(108, 14, '_role', 'field_55341f0e12d23'),
(109, 14, 'skills', 'HTML5, CSS, Wordpress, Responsive'),
(110, 14, '_skills', 'field_55341f3112d24'),
(111, 14, 'client', 'Noel Nissen'),
(112, 14, '_client', 'field_55341f4b12d25'),
(113, 14, 'work-image', '5'),
(114, 14, '_work-image', 'field_55341f9312d26'),
(115, 14, 'title', 'Noel Nissen, Coffee Professional'),
(116, 14, '_title', 'field_55347ffee055b'),
(117, 2, 'title', 'Noel Nissen, Coffee Professional'),
(118, 2, '_title', 'field_55347ffee055b'),
(120, 17, '_edit_last', '1'),
(121, 17, '_edit_lock', '1430073790:1'),
(122, 4, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"work";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(123, 4, 'rule', 'a:5:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:8:"work.php";s:8:"order_no";i:0;s:8:"group_no";i:1;}'),
(124, 17, 'about', 'Noel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region.'),
(125, 17, '_about', 'field_553424fb5c261'),
(126, 17, 'role', 'Logo design, web design and development'),
(127, 17, '_role', 'field_55341f0e12d23'),
(128, 17, 'skills', 'HTML5, CSS, WordPress, Responsive'),
(129, 17, '_skills', 'field_55341f3112d24'),
(130, 17, 'client', 'Noel Nissen'),
(131, 17, '_client', 'field_55341f4b12d25') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(132, 17, 'work-image', '5'),
(133, 17, '_work-image', 'field_55341f9312d26'),
(134, 17, 'title', 'Noel Nissen, Coffee Professional'),
(135, 17, '_title', 'field_55347ffee055b'),
(136, 18, '_menu_item_type', 'post_type'),
(137, 18, '_menu_item_menu_item_parent', '0'),
(138, 18, '_menu_item_object_id', '17'),
(139, 18, '_menu_item_object', 'work'),
(140, 18, '_menu_item_target', ''),
(141, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(142, 18, '_menu_item_xfn', ''),
(143, 18, '_menu_item_url', ''),
(145, 19, '_edit_last', '1'),
(146, 19, '_wp_page_template', 'home.php'),
(147, 19, '_edit_lock', '1430079472:1'),
(148, 21, '_wp_attached_file', '2015/05/discussion.png'),
(149, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:63;s:6:"height";i:59;s:4:"file";s:22:"2015/05/discussion.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(150, 22, '_wp_attached_file', '2015/05/earth.png'),
(151, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:59;s:6:"height";i:59;s:4:"file";s:17:"2015/05/earth.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(152, 23, '_wp_attached_file', '2015/05/envelope.png'),
(153, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:55;s:6:"height";i:64;s:4:"file";s:20:"2015/05/envelope.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(154, 21, '_edit_lock', '1430538378:1'),
(155, 22, '_edit_lock', '1430538612:1'),
(156, 23, '_edit_lock', '1430538646:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2015-04-17 02:08:50', '2015-04-17 02:08:50', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2015-04-17 02:08:50', '2015-04-17 02:08:50', '', 0, 'http://samanthanissen.com/?p=1', 0, 'post', '', 1),
(2, 1, '2015-04-17 02:08:50', '2015-04-17 02:08:50', '', 'Noel Nissen, Coffee Professional', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2015-04-20 04:27:11', '2015-04-20 04:27:11', '', 0, 'http://samanthanissen.com/?page_id=2', 0, 'page', '', 0),
(4, 1, '2015-04-19 21:36:21', '2015-04-19 21:36:21', '', 'Work', '', 'publish', 'closed', 'closed', '', 'acf_work', '', '', '2015-04-26 18:43:59', '2015-04-26 18:43:59', '', 0, 'http://samanthanissen.com/?post_type=acf&#038;p=4', 0, 'acf', '', 0),
(5, 1, '2015-04-19 21:40:26', '2015-04-19 21:40:26', 'Noel Nissen', 'Processed with VSCOcam with c1 preset', 'Noel Nissen', 'inherit', 'open', 'open', '', 'processed-with-vscocam-with-c1-preset', '', '', '2015-04-19 21:40:39', '2015-04-19 21:40:39', '', 2, 'http://samanthanissen.com/wp-content/uploads/2015/04/noel-nissen.jpg', 0, 'attachment', 'image/jpeg', 0),
(6, 1, '2015-04-19 21:41:32', '2015-04-19 21:41:32', '<div class="page" title="Page 2">\n<div class="section">\n<div class="layoutArea">\n<div class="column">\n\nNoel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region. [will add more about it at a later time]\n\n</div>\n</div>\n</div>\n</div>', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-autosave-v1', '', '', '2015-04-19 21:41:32', '2015-04-19 21:41:32', '', 2, 'http://samanthanissen.com/?p=6', 0, 'revision', '', 0),
(7, 1, '2015-04-19 21:42:02', '2015-04-19 21:42:02', 'Noel Nissen, a coffee professional based in Iowa, is looking to position himself as an industry expert in the Midwest region.', 'Noel Nissen, Coffee Professional', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-04-19 21:42:02', '2015-04-19 21:42:02', '', 2, 'http://samanthanissen.com/?p=7', 0, 'revision', '', 0),
(8, 1, '2015-04-19 21:59:13', '2015-04-19 21:59:13', '', 'Noel Nissen, Coffee Professional', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-04-19 21:59:13', '2015-04-19 21:59:13', '', 2, 'http://samanthanissen.com/?p=8', 0, 'revision', '', 0),
(9, 1, '2015-04-19 22:09:00', '2015-04-19 22:09:00', '', 'Contact', '', 'publish', 'open', 'open', '', 'home', '', '', '2015-04-26 19:51:29', '2015-04-26 19:51:29', '', 0, 'http://samanthanissen.com/?p=9', 3, 'nav_menu_item', '', 0),
(12, 1, '2015-04-19 22:10:36', '2015-04-19 22:10:36', '', 'Home', '', 'publish', 'open', 'open', '', 'home-2', '', '', '2015-04-26 19:51:29', '2015-04-26 19:51:29', '', 0, 'http://samanthanissen.com/?p=12', 1, 'nav_menu_item', '', 0),
(13, 1, '2015-04-19 22:23:53', '2015-04-19 22:23:53', '', 'Noel Nissen, Coffee Professional', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-04-19 22:23:53', '2015-04-19 22:23:53', '', 2, 'http://samanthanissen.com/?p=13', 0, 'revision', '', 0),
(14, 1, '2015-04-20 04:27:11', '2015-04-20 04:27:11', '', 'Noel Nissen, Coffee Professional', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-04-20 04:27:11', '2015-04-20 04:27:11', '', 2, 'http://samanthanissen.com/?p=14', 0, 'revision', '', 0),
(15, 1, '2015-04-26 18:10:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-04-26 18:10:38', '0000-00-00 00:00:00', '', 0, 'http://samanthanissen.com/?p=15', 0, 'post', '', 0),
(16, 1, '2015-04-26 18:42:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-04-26 18:42:32', '0000-00-00 00:00:00', '', 0, 'http://samanthanissen.com/?post_type=work&p=16', 0, 'work', '', 0),
(17, 1, '2015-04-26 18:45:31', '2015-04-26 18:45:31', '', 'Noel Nissen, Coffee Professional', '', 'publish', 'closed', 'closed', '', 'noel-nissen-coffee-professional', '', '', '2015-04-26 18:45:31', '2015-04-26 18:45:31', '', 0, 'http://samanthanissen.com/?post_type=work&#038;p=17', 0, 'work', '', 0),
(18, 1, '2015-04-26 18:47:52', '2015-04-26 18:47:52', '', 'Work', '', 'publish', 'open', 'open', '', '18', '', '', '2015-04-26 19:51:29', '2015-04-26 19:51:29', '', 0, 'http://samanthanissen.com/?p=18', 2, 'nav_menu_item', '', 0),
(19, 1, '2015-04-26 20:20:13', '2015-04-26 20:20:13', '', '', '', 'publish', 'open', 'open', '', '19', '', '', '2015-04-26 20:20:13', '2015-04-26 20:20:13', '', 0, 'http://samanthanissen.com/?page_id=19', 0, 'page', '', 0),
(20, 1, '2015-04-26 20:20:13', '2015-04-26 20:20:13', '', '', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 20:20:13', '2015-04-26 20:20:13', '', 19, 'http://samanthanissen.com/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2015-05-02 03:46:09', '2015-05-02 03:46:09', '', 'discussion', '', 'inherit', 'open', 'open', '', 'discussion', '', '', '2015-05-02 03:46:09', '2015-05-02 03:46:09', '', 0, 'http://samanthanissen.com/wp-content/uploads/2015/05/discussion.png', 0, 'attachment', 'image/png', 0),
(22, 1, '2015-05-02 03:46:09', '2015-05-02 03:46:09', '', 'earth', '', 'inherit', 'open', 'open', '', 'earth', '', '', '2015-05-02 03:46:09', '2015-05-02 03:46:09', '', 0, 'http://samanthanissen.com/wp-content/uploads/2015/05/earth.png', 0, 'attachment', 'image/png', 0),
(23, 1, '2015-05-02 03:46:10', '2015-05-02 03:46:10', '', 'envelope', '', 'inherit', 'open', 'open', '', 'envelope', '', '', '2015-05-02 03:46:10', '2015-05-02 03:46:10', '', 0, 'http://samanthanissen.com/wp-content/uploads/2015/05/envelope.png', 0, 'attachment', 'image/png', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(9, 2, 0),
(12, 2, 0),
(18, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'primary', 'primary', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'snissen'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:2:{s:64:"15b22c6dc20f74c5ddfb82480a48b16d3cc500d4f559ec91195714fd1201568e";a:4:{s:10:"expiration";i:1430619657;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:37.0) Gecko/20100101 Firefox/37.0";s:5:"login";i:1430446857;}s:64:"81cb04d9a5aa58a8f41840f0cb87d2ef41143e202079df43171e3076bc2b2a7f";a:4:{s:10:"expiration";i:1430708806;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:37.0) Gecko/20100101 Firefox/37.0";s:5:"login";i:1430536006;}}'),
(15, 1, 'wp_user-settings', 'libraryContent=browse&imgsize=full&editor=tinymce&hidetb=1'),
(16, 1, 'wp_user-settings-time', '1429479717'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '15'),
(18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(20, 1, 'closedpostboxes_wpmove-ma-restore', 'a:0:{}'),
(21, 1, 'closedpostboxes_wpmove-ma-migrate', 'a:1:{i:0;s:17:"wpmove-ma-migrate";}'),
(22, 1, 'closedpostboxes_wpmove-ma-domain', 'a:0:{}'),
(23, 1, 'metaboxhidden_wpmove-ma-migrate', 'a:0:{}'),
(24, 1, 'metaboxhidden_wpmove-ma-restore', 'a:0:{}'),
(25, 1, 'metaboxhidden_wpmove-ma-domain', 'a:0:{}'),
(26, 1, 'nav_menu_recently_edited', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'snissen', '$P$B1rJiuZ3C98Kf2shL87emxhnQHyvxc1', 'snissen', 'samanthaknissen@gmail.com', '', '2015-04-17 02:08:50', '', 0, 'snissen') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

